<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" >
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>�n�J</title>
		<meta http-equiv="X-UA-Compatible" content="IE=9"></meta>
		
        <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.2.1/css/bootstrap-combined.min.css" rel="stylesheet"/>
        <script src="buzz.js" type="text/javascript"></script>    
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js"></script>
		
		<script>
			$(document).ready(function(){
				var mySound = new buzz.sound(["cos.mp3", "cos.ogg"]);
				
				mySound.load();
				mySound.play();
				
				mySound.setSpeed(1.9);
            });
			
		</script>    		
	</head>
			
	<body>
		<?		
			echo "asdsadds";
		?>



	</body>
</html>
